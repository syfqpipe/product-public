from django.apps import AppConfig


class FreeformsConfig(AppConfig):
    name = 'freeforms'
