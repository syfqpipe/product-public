from django.apps import AppConfig


class OrganisationsConfig(AppConfig):
    name = 'organisations'
