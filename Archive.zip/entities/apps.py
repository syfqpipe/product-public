from django.apps import AppConfig


class OutfitsConfig(AppConfig):
    name = 'outfits'
