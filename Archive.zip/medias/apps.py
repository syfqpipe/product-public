from django.apps import AppConfig


class MediasConfig(AppConfig):
    name = 'medias'
